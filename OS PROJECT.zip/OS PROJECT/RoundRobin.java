import java.util.*;

class Process {
    int pid, arrivalTime, burstTime, remainingTime, waitingTime, turnaroundTime;
}

public class RoundRobin {
    public static void main(String[] args) {
        int quantum = 2;
        Queue<Process> queue = new LinkedList<>();
        List<Process> processes = Arrays.asList(
            new Process(){ pid=1; arrivalTime=0; burstTime=5; remainingTime=5; },
            new Process(){ pid=2; arrivalTime=1; burstTime=4; remainingTime=4; },
            new Process(){ pid=3; arrivalTime=2; burstTime=2; remainingTime=2; }
        );

        int time = 0;
        queue.addAll(processes);

        while (!queue.isEmpty()) {
            Process p = queue.poll();

            if (p.arrivalTime > time) {
                time = p.arrivalTime;
            }

            int execTime = Math.min(quantum, p.remainingTime);
            p.remainingTime -= execTime;
            time += execTime;

            if (p.remainingTime > 0) {
                p.arrivalTime = time;
                queue.offer(p);
            } else {
                p.turnaroundTime = time - p.arrivalTime + (p.burstTime - p.remainingTime);
                p.waitingTime = p.turnaroundTime - p.burstTime;
            }
        }

        for (Process p : processes) {
            System.out.println("Process " + p.pid + ": Waiting Time = " + p.waitingTime + ", Turnaround Time = " + p.turnaroundTime);
        }
    }
}
