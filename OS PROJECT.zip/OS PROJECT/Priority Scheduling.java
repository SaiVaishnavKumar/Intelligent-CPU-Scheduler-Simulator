import java.util.*;

class Process {
    int pid, arrivalTime, burstTime, priority, waitingTime, turnaroundTime;
}

public class PriorityScheduling {
    public static void main(String[] args) {
        List<Process> processes = new ArrayList<>();
        processes.add(new Process(){ pid=1; arrivalTime=0; burstTime=5; priority=2; });
        processes.add(new Process(){ pid=2; arrivalTime=1; burstTime=3; priority=1; });
        processes.add(new Process(){ pid=3; arrivalTime=2; burstTime=4; priority=3; });

        processes.sort(Comparator.comparingInt(p -> p.priority)); // lower value = higher priority
        int currentTime = 0;

        for (Process p : processes) {
            if (currentTime < p.arrivalTime)
                currentTime = p.arrivalTime;

            p.waitingTime = currentTime - p.arrivalTime;
            currentTime += p.burstTime;
            p.turnaroundTime = p.waitingTime + p.burstTime;
        }

        for (Process p : processes) {
            System.out.println("Process " + p.pid + ": Waiting Time = " + p.waitingTime + ", Turnaround Time = " + p.turnaroundTime);
        }
    }
}

