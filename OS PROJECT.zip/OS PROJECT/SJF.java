import java.util.*;

class Process {
    int pid, arrivalTime, burstTime, waitingTime, turnaroundTime;
}

public class SJF {
    public static void main(String[] args) {
        List<Process> processes = new ArrayList<>();
        processes.add(new Process(){ pid=1; arrivalTime=0; burstTime=6; });
        processes.add(new Process(){ pid=2; arrivalTime=1; burstTime=2; });
        processes.add(new Process(){ pid=3; arrivalTime=2; burstTime=8; });

        int currentTime = 0;
        List<Process> completed = new ArrayList<>();

        while (!processes.isEmpty()) {
            Process next = processes.stream()
                .filter(p -> p.arrivalTime <= currentTime)
                .min(Comparator.comparingInt(p -> p.burstTime))
                .orElse(null);

            if (next == null) {
                currentTime++;
                continue;
            }

            next.waitingTime = currentTime - next.arrivalTime;
            currentTime += next.burstTime;
            next.turnaroundTime = next.waitingTime + next.burstTime;

            completed.add(next);
            processes.remove(next);
        }

        for (Process p : completed) {
            System.out.println("Process " + p.pid + ": Waiting Time = " + p.waitingTime + ", Turnaround Time = " + p.turnaroundTime);
        }
    }
}
