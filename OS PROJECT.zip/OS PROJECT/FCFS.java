class Process {
    int pid, arrivalTime, burstTime, waitingTime, turnaroundTime;
}

public class FCFS {
    public static void main(String[] args) {
        Process[] processes = {
            new Process(){ pid=1; arrivalTime=0; burstTime=4; },
            new Process(){ pid=2; arrivalTime=1; burstTime=3; },
            new Process(){ pid=3; arrivalTime=2; burstTime=1; }
        };
        int n = processes.length;
        int currentTime = 0;
        for (int i = 0; i < n; i++) {
            Process p = processes[i];
            if (currentTime < p.arrivalTime)
                currentTime = p.arrivalTime;

            p.waitingTime = currentTime - p.arrivalTime;
            currentTime += p.burstTime;
            p.turnaroundTime = p.waitingTime + p.burstTime;
        }

        for (Process p : processes) {
            System.out.println("Process " + p.pid + ": Waiting Time = " + p.waitingTime + ", Turnaround Time = " + p.turnaroundTime);
        }
    }
}
